package com.coffeepoweredcrew.prototype;

public class Client {

	public static void main(String[] args) {
        
	}

}
